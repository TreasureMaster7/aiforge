// V2 Playwright Test
const { chromium } = require('playwright');
const path = require('path');

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  const v2Path = path.join(__dirname, 'index.html');
  const url = 'file://' + v2Path;

  const errors = [];
  const consoleMessages = [];

  page.on('console', msg => {
    consoleMessages.push(`[${msg.type()}] ${msg.text()}`);
    if (msg.type() === 'error') errors.push(msg.text());
  });
  page.on('pageerror', err => errors.push(`PAGE ERROR: ${err.message}`));

  const tests = [];

  // Test 1: Homepage
  console.log('1. Testing index.html...');
  await page.goto(url, { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  const title = await page.title();
  const heroH1 = await page.locator('h1').first().textContent();
  const trendingCount = await page.locator('#trending-grid .tool-card, #trending-grid > *').count();
  const categoriesCount = await page.locator('#categories-grid > *').count();
  tests.push({ name: 'Homepage loads', pass: title.includes('AI Forge') });
  tests.push({ name: 'Hero heading present', pass: heroH1 && heroH1.includes('AI') });
  tests.push({ name: 'Trending tools rendered', pass: trendingCount > 0, val: `${trendingCount} items` });
  tests.push({ name: 'Categories rendered', pass: categoriesCount >= 9, val: `${categoriesCount} items` });
  await page.screenshot({ path: path.join(__dirname, 'screenshot-home.png'), fullPage: true });

  // Test 2: Tools page
  console.log('2. Testing tools.html...');
  await page.goto('file://' + path.join(__dirname, 'tools.html'), { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  const toolsCount = await page.locator('#all-tools-grid > *').count();
  const filterBtns = await page.locator('.filter-btn[data-filter]').count();
  tests.push({ name: 'Tools page loads', pass: true });
  tests.push({ name: 'All 54 tools rendered', pass: toolsCount >= 50, val: `${toolsCount} tools` });
  tests.push({ name: 'Filter buttons present', pass: filterBtns >= 10, val: `${filterBtns} filters` });

  // Test filter interaction
  await page.locator('.filter-btn[data-filter="code"]').click();
  await page.waitForTimeout(300);
  const codeCount = await page.locator('#all-tools-grid > *').count();
  tests.push({ name: 'Category filter works', pass: codeCount > 0 && codeCount < toolsCount, val: `${codeCount} code tools` });

  // Test search
  await page.locator('.filter-btn[data-filter="all"]').click();
  await page.waitForTimeout(200);
  await page.locator('#tools-search').fill('video');
  await page.waitForTimeout(400);
  const searchCount = await page.locator('#all-tools-grid > *').count();
  tests.push({ name: 'Search works', pass: searchCount > 0, val: `${searchCount} results for "video"` });
  await page.screenshot({ path: path.join(__dirname, 'screenshot-tools.png'), fullPage: true });

  // Test 3: Blog page
  console.log('3. Testing blog.html...');
  await page.goto('file://' + path.join(__dirname, 'blog.html'), { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  const blogCards = await page.locator('.blog-card').count();
  const featured = await page.locator('.featured-article').count();
  const newsletter = await page.locator('.newsletter-card').count();
  tests.push({ name: 'Blog page loads', pass: true });
  tests.push({ name: 'Featured article present', pass: featured === 1, val: `${featured} featured` });
  tests.push({ name: 'Blog cards present', pass: blogCards >= 6, val: `${blogCards} posts` });
  tests.push({ name: 'Newsletter section present', pass: newsletter === 1 });
  await page.screenshot({ path: path.join(__dirname, 'screenshot-blog.png'), fullPage: true });

  // Test 4: Submit page
  console.log('4. Testing submit.html...');
  await page.goto('file://' + path.join(__dirname, 'submit.html'), { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  const processSteps = await page.locator('.process-step').count();
  const formInputs = await page.locator('input, select, textarea').count();
  const sidebarCards = await page.locator('.sidebar-card').count();
  tests.push({ name: 'Submit page loads', pass: true });
  tests.push({ name: 'Process steps present', pass: processSteps === 4, val: `${processSteps} steps` });
  tests.push({ name: 'Form fields present', pass: formInputs >= 8, val: `${formInputs} fields` });
  tests.push({ name: 'Sidebar cards present', pass: sidebarCards >= 3, val: `${sidebarCards} cards` });
  await page.screenshot({ path: path.join(__dirname, 'screenshot-submit.png'), fullPage: true });

  // Test 5: Mobile responsiveness
  console.log('5. Testing mobile responsiveness...');
  await page.setViewportSize({ width: 375, height: 667 });
  await page.goto(url, { waitUntil: 'networkidle' });
  await page.waitForTimeout(500);
  const mobileNav = await page.locator('.mobile-toggle').isVisible();
  tests.push({ name: 'Mobile nav toggle visible', pass: mobileNav });
  await page.screenshot({ path: path.join(__dirname, 'screenshot-mobile.png'), fullPage: false });

  // Test 6: Dark theme & futuristic elements
  console.log('6. Testing visual elements...');
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto(url, { waitUntil: 'networkidle' });
  await page.waitForTimeout(800);
  const auroraGrad = await page.locator('.gradient-text').count();
  const glassCards = await page.locator('.tool-card').count();
  tests.push({ name: 'Aurora gradient text present', pass: auroraGrad > 5, val: `${auroraGrad} elements` });
  tests.push({ name: 'Glassmorphic tool cards', pass: glassCards > 0 });

  // Report
  console.log('\n=== TEST RESULTS ===');
  let pass = 0;
  let fail = 0;
  for (const t of tests) {
    const status = t.pass ? '✓' : '✗';
    const val = t.val ? ` (${t.val})` : '';
    console.log(`  ${status} ${t.name}${val}`);
    t.pass ? pass++ : fail++;
  }
  console.log(`\n${pass}/${tests.length} tests passed, ${fail} failed`);

  if (errors.length > 0) {
    console.log('\nErrors:');
    errors.forEach(e => console.log('  -', e));
  } else {
    console.log('\nNo console errors!');
  }

  await browser.close();
  process.exit(fail > 0 ? 1 : 0);
})();
